#ifndef ReadDataIn_H_
#define ReadDataIn_H_


#include "./FilterGenotype.h"


using namespace std;

inline int GetBestBase (string Genotype, map <string ,char > SNP_Allele , map <string,string >  & SNP_back_Allele ,  vector <BaseType> &  Base_list )
{
	vector<string>  Base1 ;
	split(Genotype, Base1," \t");
	map <char,int > Count ;
	int Asize=Base1.size();
	for (int ii=0 ;ii<Asize ; ii++)
	{
		string A_tmp=SNP_back_Allele[Base1[ii]];
		Count[A_tmp[0]]++;
		Count[A_tmp[1]]++;
	}
	char best_base='N';
	char sed_base='N';
	int Max=0;
	int SeD=0;
	map <char,int>  :: iterator it=Count.begin();
	for ( ; it!=Count.end(); it++ )
	{
		if ( (it->first ) == 'N' )
		{
			continue ;
		}
		else if ((it->second)  > Max )
		{
			SeD=Max;
			sed_base=best_base;
			Max=(it->second);
			best_base=it->first;
		}
		else if ( (it->second)  >= SeD )
		{
			SeD=(it->second);
			sed_base=it->first;
		}
	}

	map <string ,string > Allele2double;
	Allele2double["-"]="NN";
	Allele2double["N"]="NN";
	Allele2double["n"]="NN";
	string tmp="";
	string A_base=best_base+tmp;
	string B_base=sed_base+tmp;
	string Het_base=A_base+B_base;
	string C_base=SNP_Allele[Het_base]+tmp;

	Allele2double[A_base]=(A_base+A_base);
	Allele2double[B_base]=(B_base+B_base);
	Allele2double[C_base]=Het_base;
	BaseType TempType ;
	//	TempType.Value=0;		Base_list.push_back(TempType);
	//	TempType.Value=1;		Base_list.push_back(TempType);

	for (int ii=0 ;ii<Asize ; ii++)
	{
		string A_tmp=Allele2double[Base1[ii]];
		if (A_tmp=="") 		{	A_tmp=Het_base;	}

		if (A_tmp[0] == best_base )
		{
			TempType.Value=0;
		}
		else if (A_tmp[0] == sed_base )
		{
			TempType.Value=1;
		}
		else
		{
			TempType.Value=2; 
		}
		Base_list.push_back(TempType);

		if (A_tmp[1] == best_base  )
		{
			TempType.Value=0;
		}
		else if (A_tmp[1] == sed_base )
		{
			TempType.Value=1;
		}
		else
		{
			TempType.Value=2; 
		}
		Base_list.push_back(TempType);
	}


	return 1;
}



inline int Read_SubPopVCF_IN(In3str1v * paraFA04, Para_18 * para_18 , map <string,map <llong, vector <BaseType> > > &  SNPList ,int & Flag_for_pro )
{
	igzstream SampleList ((paraFA04->SubPop).c_str(),ifstream::in);
	if (SampleList.fail())
	{
		cerr << "open Sub Group IN File error: "<<(paraFA04->SubPop)<<endl;
		return  0;
	}

	map <string ,int >  SubVetor;
	map <string ,int >  :: iterator it;

	while(!SampleList.eof())
	{
		string  line ;
		getline(SampleList,line);
		if (line.length()<=0 || line[0] == '#' )  { continue  ; }
		vector<string> inf ;
		split(line,inf," \t");
		int A=inf.size();
		for(int ii=0 ; ii<A ; ii++)
		{
			it=SubVetor.find(inf[ii]);
			if (it==SubVetor.end())
			{
				SubVetor.insert(map <string ,int> ::value_type(inf[ii],1));
			}
			else
			{
				(it->second)++;
			}
		}
	}
	SampleList.close();

	igzstream VCFIN ((paraFA04->InStr1).c_str(),ifstream::in);
	if (VCFIN.fail())
	{
		cerr << "open VCF File IN File error: "<<(paraFA04->InStr1)<<endl;
		delete  paraFA04 ; return  0;
	}

	vector <int> SampleSite;
	while(!VCFIN.eof())
	{
		string  line ;
		getline(VCFIN,line);
		if (line.length()<=0 )  { continue  ; }
		else if (line[0] == '#' && line[1] == '#' )  { continue  ; }
		else if( line[0] == '#' && line[1] != '#')
		{
			vector<string> Vsample ;
			split(line,Vsample," \t");
			if  ( Vsample[0]  != "#CHROM")  
			{
				continue  ;
			}
			int A=Vsample.size();
			for(int ii=9 ; ii< A ; ii++)
			{
				it=SubVetor.find(Vsample[ii]);
				if (it!=SubVetor.end())
				{
					SampleSite.push_back(ii);
				}
			}
			break ;
		}
		else if ( line[0] != '#' && line[1] != '#' )
		{
			cerr<<"wrong Line : "<<line<<endl;
			cerr<<"VCF Header same thing wrong, can find sample info before site info"<<endl;
			cerr<<"VCF Header sample info Flag : [  #CHROM  ] "<<endl;
			return  0;
			break;
		}
	}

	int NumberSubGroup=SampleSite.size();
	cout<<"the Number of subPop samples[found in VCF] is "<<NumberSubGroup<<endl;
	if (NumberSubGroup<3)
	{
		cerr<<"sub Group Population szie is too small, SubGroup sample size: "<<NumberSubGroup<<endl;
		return  0;
	}

	int BadSite=0;
	int BadIndelSite=0;

	while(!VCFIN.eof())
	{
		string  line ;
		getline(VCFIN,line);
		if (line.length()<=0  )  { continue  ; }
		string GeneID  ;
		llong Site ;
		vector<string> inf ;
		split(line,inf," \t");
		int  Base_len=inf[3].length();
		vector<string> Alt ;
		split(inf[4],Alt,",");
		map <int,string> Num2Base ;
		Num2Base[0]=inf[3];
		for (int ii=0 ; ii<Alt.size() ;ii++)
		{
			if (Alt[ii].length()>Base_len)
			{
				Base_len=Alt[ii].length();
			}
			int j=ii+1;
			Num2Base[j]=Alt[ii];
		}


		if (Base_len>1)
		{
			BadIndelSite++;
			continue ;
		}


		int Asample=inf.size();		
		map <char,int > Count ;
		int Het_count=0;
		int Miss_count=0;


		for (int kk=0 ; kk< NumberSubGroup ; kk++)
		{
			vector<string> Btmp  ;
			split(inf[SampleSite[kk]], Btmp,":");
			string Genotype=Btmp[0];
			char ABase=Genotype[0];
			if (  ABase == '.' )
			{
				Miss_count++ ;
			}
			else
			{
				char BBase=Genotype[2];
				if  (ABase != BBase )
				{
					Het_count++;
				}
				Count[ABase]++;
				Count[BBase]++;
			}
		}


		if ( ( (Miss_count*1.0/NumberSubGroup)  >(para_18->Miss)  )  )
		{
			continue ;
		}

		if ( ( (Het_count*1.0/NumberSubGroup)  >(para_18->Het) )  )
		{
			continue ;
		}

		int BaseConut=0;
		char best_base='N';
		char sed_base='N';
		int Max=0;
		int SeD=0;		
		map <char,int>  :: iterator it=Count.begin();

		for ( ; it!=Count.end(); it++ )
		{
			if ( (it->first ) == 'N' )
			{
				continue ;
			}
			else if ((it->second)  > Max )
			{
				SeD=Max;
				sed_base=best_base;
				Max=(it->second);
				best_base=it->first;
			}
			else if ( (it->second)  >= SeD )
			{
				SeD=(it->second);
				sed_base=it->first;
			}
			BaseConut++;
		}
		if (BaseConut==1 || BaseConut >2 )
		{
			BadSite++;
			continue ;
		}

		//if ( (  (1-(Max*0.5/NumberSubGroup))  < (para_18->MAF) )  )
		if ( (SeD*1.0/(SeD+Max))  < (para_18->MAF) )  
		{
			continue ;
		}

		vector<BaseType>  genotypeVE ;

		BaseType  TypeA;


		vector<char>  genotype ;
		for (int kk=0 ; kk< NumberSubGroup ; kk++)
		{
			vector<string> Btmp  ;
			split(inf[SampleSite[kk]], Btmp,":");
			string Genotype=Btmp[0];
			char ABase=Genotype[0];
			if (  ABase == '.' )
			{
				genotype.push_back('N');
				genotype.push_back('N');
			}
			else
			{
				char BBase=Genotype[2];
				if  (ABase != BBase)
				{
				genotype.push_back(best_base);
				genotype.push_back(sed_base);
				}
				else
				{
				genotype.push_back(ABase);
				genotype.push_back(BBase);
				}
			}
		}





		int ERA=genotype.size();
		for (int hh=0 ; hh<ERA ;hh++)
		{

			if (genotype[hh] == best_base  )
			{
				TypeA.Value=0;
			}
			else if (genotype[hh] == sed_base )
			{
				TypeA.Value=1;
			}
			else
			{
				TypeA.Value=2; 
			}
			genotypeVE.push_back(TypeA);	
		}

		GeneID=inf[0];
		istringstream isone (inf[1],istringstream::in);
		isone>> Site ;


		map <string,map <llong, vector <BaseType> > >  :: iterator itSNP=SNPList.find(GeneID);

		if (itSNP == SNPList.end())
		{
			map <llong, vector <BaseType> > DD;
			DD[Site]=genotypeVE;
			SNPList.insert(map <string,map <llong,vector <BaseType> > > ::value_type(GeneID,DD));
			Flag_for_pro++;
		}
		else
		{
			(itSNP->second).insert(map <llong, vector <BaseType> >  :: value_type(Site,genotypeVE)) ;
			Flag_for_pro++;
		}
	}

	if(BadIndelSite!=0)
	{
		cerr<<"warning skip Indel site, there are total skip Indel sites number is : "<<BadIndelSite<<endl;
	}
	if (BadSite!=0)
	{
		cerr<<"Warning skip non bi-allelic(Singleton/ThreeMulti allelic) site, and total skip allelic sites number is :"<<BadSite<<endl;
	}


}



inline int Read_VCF_IN(In3str1v * paraFA04, Para_18 * para_18 , map <string,map <llong, vector <BaseType> > > &  SNPList ,int & Flag_for_pro )
{

	igzstream VCFIN ((paraFA04->InStr1).c_str(),ifstream::in);

	if (VCFIN.fail())
	{
		cerr << "open VCF File IN File error: "<<(paraFA04->InStr1)<<endl;
		delete  paraFA04 ; return  0;
	}

	int BadSite=0 ;
	int BadIndelSite=0;
	if (paraFA04->TF2)
	{

		while(!VCFIN.eof())
		{
			string  line ;
			getline(VCFIN,line);
			if (line.length()<=0 || line[0] == '#' )  { continue  ; }
			string GeneID  ;
			llong Site ;
			vector<string> inf ;
			split(line,inf," \t");
			int  Base_len=inf[3].length();
			vector<string> Alt ;
			split(inf[4],Alt,",");
			map <int,string> Num2Base ;
			Num2Base[0]=inf[3];
			for (int ii=0 ; ii<Alt.size() ;ii++)
			{
				if (Alt[ii].length()>Base_len)
				{
					Base_len=Alt[ii].length();
				}
				int j=ii+1;
				Num2Base[j]=Alt[ii];
			}

			if (Base_len>1)
			{
				BadIndelSite++;
				continue ;
			}


			int Asample=inf.size();		
			map <char,int > Count ;
			int Het_count=0;
			int Miss_count=0;


			for (int jj=9 ; jj< Asample ;jj++ )
			{
				vector<string> Btmp  ;
				split(inf[jj], Btmp,":");
				string Genotype=Btmp[0];
				char ABase=Genotype[0];
				if (  ABase == '.' )
				{
					Miss_count++ ;
				}
				else
				{
					char BBase=Genotype[2];
					if  (ABase != BBase )
					{
						Het_count++;
					}
					Count[ABase]++;
					Count[BBase]++;
				}
			}

			int SampleNum=(Asample-9);
			if ( ( (Miss_count*1.0/SampleNum)  >(para_18->Miss)  )  )
			{
				continue ;
			}

			if ( ( (Het_count*1.0/SampleNum)  >(para_18->Het) )  )
			{
				continue ;
			}

			int BaseConut=0;
			char best_base='N';
			char sed_base='N';
			int Max=0;
			int SeD=0;		
			map <char,int>  :: iterator it=Count.begin();

			for ( ; it!=Count.end(); it++ )
			{
				if ( (it->first ) == 'N' )
				{
					continue ;
				}
				else if ((it->second)  > Max )
				{
					SeD=Max;
					sed_base=best_base;
					Max=(it->second);
					best_base=it->first;
				}
				else if ( (it->second)  >= SeD )
				{
					SeD=(it->second);
					sed_base=it->first;
				}
				BaseConut++;
			}
			if (BaseConut==1 || BaseConut >2 )
			{
				BadSite++;
				continue ;
			}

			//if ( (  (1-(Max*0.5/SampleNum))  < (para_18->MAF) )  )
			if ( (SeD*1.0/(SeD+Max))  < (para_18->MAF) )  
			{
				continue ;
			}



			vector<char>  genotype ;

			for (int jj=9 ; jj< Asample ;jj++ )
			{
				vector<string> Btmp  ;
				split(inf[jj], Btmp,":");
				string Genotype=Btmp[0];
				char ABase=Genotype[0];
				if (  ABase == '.' )
				{
					genotype.push_back('N');
					genotype.push_back('N');
				}
				else
				{
					char BBase=Genotype[2];
					if  (ABase != BBase )	
					{
						genotype.push_back(best_base);
						genotype.push_back(sed_base);
					}					
					else
					{
						genotype.push_back(ABase);
						genotype.push_back(BBase);
					}
				}
			}





			vector<BaseType>  genotypeVE ;

			BaseType  TypeA;


			int ERA=genotype.size();
			for (int hh=0 ; hh<ERA ;hh++)
			{

				if (genotype[hh] == best_base  )
				{
					TypeA.Value=0;
				}
				else if (genotype[hh] == sed_base )
				{
					TypeA.Value=1;
				}
				else
				{
					TypeA.Value=2; 
				}
				genotypeVE.push_back(TypeA);
			}






			GeneID=inf[0];
			istringstream isone (inf[1],istringstream::in);
			isone>> Site ;


			map <string,map <llong, vector <BaseType> > >  :: iterator itSNP=SNPList.find(GeneID);

			if (itSNP == SNPList.end())
			{
				map <llong, vector <BaseType> > DD;
				DD[Site]=genotypeVE;
				SNPList.insert(map <string,map <llong,vector <BaseType> > > ::value_type(GeneID,DD));
				Flag_for_pro++;
			}
			else
			{
				(itSNP->second).insert(map <llong, vector <BaseType> >  :: value_type(Site,genotypeVE)) ;
				Flag_for_pro++;
			}
		}



	}
	else
	{

		string OUT_VCFTMP=(paraFA04->InStr2)+".vcf.filter.gz";
		ogzstream OUTVCFFF ((OUT_VCFTMP).c_str());

		while(!VCFIN.eof())
		{
			string  line ;
			getline(VCFIN,line);
			if (line.length()<=0 || line[0] == '#' )  { continue  ; }
			string GeneID  ;
			llong Site ;
			vector<string> inf ;
			split(line,inf," \t");
			int  Base_len=inf[3].length();
			vector<string> Alt ;
			split(inf[4],Alt,",");
			map <int,string> Num2Base ;
			Num2Base[0]=inf[3];
			for (int ii=0 ; ii<Alt.size() ;ii++)
			{
				if (Alt[ii].length()>Base_len)
				{
					Base_len=Alt[ii].length();
				}
				int j=ii+1;
				Num2Base[j]=Alt[ii];
			}

			if (Base_len>1)
			{
				BadIndelSite++;
				continue ;
			}


			int Asample=inf.size();		
			map <char,int > Count ;
			int Het_count=0;
			int Miss_count=0;


			for (int jj=9 ; jj< Asample ;jj++ )
			{
				vector<string> Btmp ;
				split(inf[jj], Btmp,":");
				string Genotype=Btmp[0];
				char ABase=Genotype[0];
				if (  ABase == '.' )
				{
					Miss_count++ ;
				}
				else
				{
					char BBase=Genotype[2];
					if  (ABase != BBase )
					{
						Het_count++;
					}
					Count[ABase]++;
					Count[BBase]++;
				}
			}

			int SampleNum=(Asample-9);
			if ( ( (Miss_count*1.0/SampleNum)  >(para_18->Miss)  )  )
			{
				continue ;
			}

			if ( ( (Het_count*1.0/SampleNum)  >(para_18->Het) )  )
			{
				continue ;
			}

			int BaseConut=0;
			char best_base='N';
			char sed_base='N';
			int Max=0;
			int SeD=0;		
			map <char,int>  :: iterator it=Count.begin();

			for ( ; it!=Count.end(); it++ )
			{
				if ( (it->first ) == 'N' )					
				{
					continue ;
				}
				else if ((it->second)  > Max )
				{
					SeD=Max;
					sed_base=best_base;
					Max=(it->second);
					best_base=it->first;
				}
				else if ( (it->second)  >= SeD )
				{
					SeD=(it->second);
					sed_base=it->first;
				}
				BaseConut++;
			}
			if (BaseConut==1 || BaseConut >2 )
			{
				BadSite++;
				continue ;
			}

			//if ( (  (1-(Max*1.0/(SeD+Max)))  < (para_18->MAF) )  )
			if ( (SeD*1.0/(SeD+Max))  < (para_18->MAF) )  
			//if ( (  (1-(Max*0.5/SampleNum))  < (para_18->MAF) )  )
			{
				continue ;
			}




			vector<char>  genotype ;
			for (int jj=9 ; jj< Asample ;jj++ )
			{
				vector<string> Btmp ;
				split(inf[jj], Btmp,":");
				string Genotype=Btmp[0];
				char ABase=Genotype[0];
				if (  ABase == '.' )
				{
					genotype.push_back('N');
					genotype.push_back('N');
				}
				else
				{
					char BBase=Genotype[2];
					if  (ABase != BBase )
					{
						genotype.push_back(best_base);
						genotype.push_back(sed_base);
					}
					else
					{
						genotype.push_back(ABase);
						genotype.push_back(BBase);
					}
				}
			}



			vector<BaseType>  genotypeVE ;

			BaseType  TypeA;

			int ERA=genotype.size();
			for (int hh=0 ; hh<ERA ;hh++)
			{

				if (genotype[hh] == best_base  )
				{
					TypeA.Value=0;
				}
				else if (genotype[hh] == sed_base )
				{
					TypeA.Value=1;
				}
				else
				{
					TypeA.Value=2; 
				}
				genotypeVE.push_back(TypeA);
			}




			GeneID=inf[0];
			istringstream isone (inf[1],istringstream::in);
			isone>> Site ;


			map <string,map <llong, vector <BaseType> > >  :: iterator itSNP=SNPList.find(GeneID);
			if (itSNP == SNPList.end())
			{
				map <llong, vector <BaseType> > DD;
				DD[Site]=genotypeVE;
				SNPList.insert(map <string,map <llong,vector <BaseType> > > ::value_type(GeneID,DD));
				Flag_for_pro++;
			}
			else
			{
				(itSNP->second).insert(map <llong, vector <BaseType> >  :: value_type(Site,genotypeVE)) ;
				Flag_for_pro++;
			}

			OUTVCFFF<<line<<endl;

		}


		OUTVCFFF.close();

	}
	VCFIN.close();

	if(BadIndelSite!=0)
	{
		cerr<<"warning skip Indel site, there are total skip Indel sites number is : "<<BadIndelSite<<endl;
	}
	if (BadSite!=0)
	{
		cerr<<"Warning skip non bi-allelic(Singleton/ThreeMulti allelic) site, and total skip allelic sites number is :"<<BadSite<<endl;
	}

	return 1;
}




inline int Read_Genotype_IN(In3str1v * paraFA04, Para_18 * para_18 , map <string,map <llong, vector <BaseType> > > &  SNPList,int &  Flag_for_pro )
{
	string OUT_TMP=(paraFA04->InStr2)+".genotype.filter.gz";

	char * A = const_cast<char*>((paraFA04->InStr3).c_str());
	char * B = const_cast<char*>((OUT_TMP).c_str());
	stringstream   sstrmC ;
	sstrmC  <<  (para_18->MAF);
	string  C=sstrmC.str();
	char * MAF = const_cast<char*>((C).c_str());

	stringstream   sstrmA ;
	sstrmA  <<  (para_18->Miss);
	string  D=sstrmA.str();
	char * Miss = const_cast<char*>((D).c_str());	

	stringstream   sstrmB ;
	sstrmB  <<  (para_18->Het);
	string	 E=sstrmB.str();
	char * Het = const_cast<char*>((E).c_str());

	string  Para_1="FilterGeno";
	char * str_Para_1=const_cast<char*>((Para_1).c_str());

	string	Para_2="-InPut";
	char * str_Para_2=const_cast<char*>((Para_2).c_str());

	string	Para_3="-OutPut";
	char * str_Para_3=const_cast<char*>((Para_3).c_str());

	string	Para_4="-Cut3base";
	char * str_Para_4=const_cast<char*>((Para_4).c_str());

	string	Para_5="-Miss";
	char * str_Para_5=const_cast<char*>((Para_5).c_str());

	string	Para_6="-MAF";
	char * str_Para_6=const_cast<char*>((Para_6).c_str());

	string	Para_7="-Het";
	char * str_Para_7=const_cast<char*>((Para_7).c_str());

	char * TmpFF[12]={str_Para_1, str_Para_2, A , str_Para_3 , B , str_Para_4, str_Para_5, Miss, str_Para_6, MAF ,str_Para_7, Het };
	Filter_genotype_main( 12 ,  TmpFF );

	map <string ,char > SNP_Allele ;
	SNP_Allele["AC"]='M'; SNP_Allele["CA"]='M'; SNP_Allele["GT"]='K'; SNP_Allele["TG"]='K';
	SNP_Allele["CT"]='Y'; SNP_Allele["TC"]='Y'; SNP_Allele["AG"]='R'; SNP_Allele["GA"]='R';
	SNP_Allele["AT"]='W'; SNP_Allele["TA"]='W'; SNP_Allele["CG"]='S'; SNP_Allele["GC"]='S';
	SNP_Allele["AA"]='A'; SNP_Allele["TT"]='T'; SNP_Allele["CC"]='C'; SNP_Allele["GG"]='G';

	map <string,string > SNP_back_Allele ;
	SNP_back_Allele["M"]="AC";SNP_back_Allele["K"]="GT";SNP_back_Allele["Y"]="CT";
	SNP_back_Allele["R"]="AG";SNP_back_Allele["W"]="AT";SNP_back_Allele["S"]="CG";
	SNP_back_Allele["C"]="CC";SNP_back_Allele["G"]="GG";SNP_back_Allele["T"]="TT";
	SNP_back_Allele["A"]="AA";
	SNP_back_Allele["-"]="NN"; SNP_back_Allele["N"]="NN";

	igzstream SNP (OUT_TMP.c_str(),ifstream::in);
	if (SNP.fail())
	{
		cerr << "open SNP File error: "<<OUT_TMP<<endl;
		delete para_18 ;
		delete  paraFA04 ; return  0;
	}


	//////// swimming in the sea & flying in the sky /////////////

	while(!SNP.eof())
	{
		string  line ;
		getline(SNP,line);
		if (line.length()<=0 || line[0] == '#' )  { continue  ; }
		string GeneID  ;
		llong Site ;
		vector<string> inf ;
		split(line,inf,"\t");

		istringstream isone (inf[1],istringstream::in);
		isone>> Site ;
		GeneID=inf[0];
		vector <BaseType>  genotype ;
		GetBestBase ( inf[2] , SNP_Allele , SNP_back_Allele , genotype ) ;
		map <string,map <llong, vector <BaseType> > >  :: iterator it=SNPList.find(GeneID);
		if (it == SNPList.end())
		{
			map <llong, vector <BaseType> > DD;
			DD[Site]=genotype;
			SNPList.insert(map <string,map <llong,vector <BaseType> > > ::value_type(GeneID,DD));
			Flag_for_pro++;
		}
		else
		{
			(it->second).insert(map <llong, vector <BaseType> >  :: value_type(Site,genotype)) ;
			Flag_for_pro++;
		}
	}

	SNP.close();

	if (paraFA04->TF2)
	{
		string  MV="rm -rf  "+OUT_TMP;
		system(MV.c_str()) ;
	}


	return 1;
}





inline int Read_SubPopGenotype_IN(In3str1v * paraFA04, Para_18 * para_18 , map <string,map <llong, vector <BaseType> > > &  SNPList ,int & Flag_for_pro )
{
	igzstream SampleList ((paraFA04->SubPop).c_str(),ifstream::in);
	if (SampleList.fail())
	{
		cerr << "open Sub Group IN File error: "<<(paraFA04->SubPop)<<endl;
		return  0;
	}

	map <string ,int >  SubVetor;
	map <string ,int >  :: iterator it;

	while(!SampleList.eof())
	{
		string  line ;
		getline(SampleList,line);
		if (line.length()<=0 || line[0] == '#' )  { continue  ; }
		vector<string> inf ;
		split(line,inf," \t");
		int A=inf.size();
		for(int ii=0 ; ii<A ; ii++)
		{
			it=SubVetor.find(inf[ii]);
			if (it==SubVetor.end())
			{
				SubVetor.insert(map <string ,int> ::value_type(inf[ii],1));
			}
			else
			{
				(it->second)++;
			}
		}
	}
	SampleList.close();

	igzstream GenotypeIN ((paraFA04->InStr3).c_str(),ifstream::in);
	if (GenotypeIN.fail())
	{
		cerr << "open Genotype File IN File error: "<<(paraFA04->InStr3)<<endl;
		delete  paraFA04 ; return  0;
	}

	vector <int> SampleSite;
	while(!GenotypeIN.eof())
	{
		string  line ;
		getline(GenotypeIN,line);
		if (line.length()<=0 )  { continue  ; }
		else if (line[0] == '#' && line[1] == '#' )  { continue  ; }
		else if( line[0] == '#' && line[1] != '#')
		{
			vector<string> Vsample ;
			split(line,Vsample," \t");
			if  ( Vsample[0]  != "#CHROM")  
			{
				continue  ;
			}
			int A=Vsample.size();
			for(int ii=2 ; ii< A ; ii++)
			{
				it=SubVetor.find(Vsample[ii]);
				if (it!=SubVetor.end())
				{
					SampleSite.push_back(ii);
				}
			}
			break ;
		}
		else if ( line[0] != '#' && line[1] != '#' )
		{
			cerr<<"wrong Line : "<<line<<endl;
			cerr<<"Genotype Header same thing wrong, can find sample info before site info"<<endl;
			cerr<<"iTools   Formtools  VCF2Genotype  -InPut  in.vcf  -OutPut  out.genotype  -WithHeader   -NoRef"<<endl;
			cerr<<"Genotype Header sample info Flag : [  #CHROM  ] "<<endl;
			return  0;
			break;
		}
	}

	int NumberSubGroup=SampleSite.size();
	cout<<"the Number of subPop samples[found in Genotype] is "<<NumberSubGroup<<endl;
	if (NumberSubGroup<3)
	{
		cerr<<"sub Group Population szie is too small, SubGroup sample size: "<<NumberSubGroup<<endl;
		return  0;
	}

	int BadSite=0;



		map <string,string > SNP_back_Allele ;
		SNP_back_Allele["M"]="AC";SNP_back_Allele["K"]="GT";SNP_back_Allele["Y"]="CT";
		SNP_back_Allele["R"]="AG";SNP_back_Allele["W"]="AT";SNP_back_Allele["S"]="CG";
		SNP_back_Allele["C"]="CC";SNP_back_Allele["G"]="GG";SNP_back_Allele["T"]="TT";
		SNP_back_Allele["A"]="AA";
		SNP_back_Allele["-"]="NN"; SNP_back_Allele["N"]="NN";





	while(!GenotypeIN.eof())
	{
		string  line ;
		getline(GenotypeIN,line);
		if (line.length()<=0  )  { continue  ; }
		string GeneID  ;
		llong Site ;
		vector<string> inf ;
		split(line,inf," \t");




		int Asample=inf.size();		
		map <char,int > Count ;
		int Het_count=0;
		int Miss_count=0;



		for (int kk=0 ; kk< NumberSubGroup ; kk++)
		{
			vector<string> Btmp  ;
			string Genotype=SNP_back_Allele[inf[SampleSite[kk]]];
			char ABase=Genotype[0];
			if (  ABase == 'N' )
			{
				Miss_count++ ;
			}
			else
			{
				char BBase=Genotype[1];
				if  (ABase != BBase )
				{
					Het_count++;
				}
				Count[ABase]++;
				Count[BBase]++;
			}
		}


		if ( ( (Miss_count*1.0/NumberSubGroup)  >(para_18->Miss)  )  )
		{
			continue ;
		}

		if ( ( (Het_count*1.0/NumberSubGroup)  >(para_18->Het) )  )
		{
			continue ;
		}

		int BaseConut=0;
		char best_base='N';
		char sed_base='N';
		int Max=0;
		int SeD=0;		
		map <char,int>  :: iterator it=Count.begin();

		for ( ; it!=Count.end(); it++ )
		{
			if ( (it->first ) == 'N' )
			{
				continue ;
			}
			else if ((it->second)  > Max )
			{
				SeD=Max;
				sed_base=best_base;
				Max=(it->second);
				best_base=it->first;
			}
			else if ( (it->second)  >= SeD )
			{
				SeD=(it->second);
				sed_base=it->first;
			}
			BaseConut++;
		}
		if (BaseConut==1 || BaseConut >2 )
		{
			BadSite++;
			continue ;
		}

		//if ( (  (1-(Max*1.0/(SeD+Max)))  < (para_18->MAF) )  )
		if ( (SeD*1.0/(SeD+Max))  < (para_18->MAF) )  
		{
			continue ;
		}


		vector<BaseType>  genotypeVE ;
		BaseType  TypeA;

//		cerr<<best_base<<"\t"<<Max<<"\t"<<sed_base<<"\t"<<SeD<<endl;

		vector<char>  genotype ;
		for (int kk=0 ; kk< NumberSubGroup ; kk++)
		{
			vector<string> Btmp  ;
			string Genotype=SNP_back_Allele[inf[SampleSite[kk]]];
			char ABase=Genotype[0];
			if ( ABase == 'N' )
			{
				genotype.push_back('N');
				genotype.push_back('N');
			}
			else
			{
				char BBase=Genotype[1];
				if  (ABase != BBase )
				{
					genotype.push_back(best_base);
					genotype.push_back(sed_base);
				}
				else
				{
				genotype.push_back(ABase);
				genotype.push_back(BBase);
				}
			}
		}





		int ERA=genotype.size();
		for (int hh=0 ; hh<ERA ;hh++)
		{

			if (genotype[hh] == best_base  )
			{
				TypeA.Value=0;
			}
			else if (genotype[hh] == sed_base )
			{
				TypeA.Value=1;
			}
			else
			{
				TypeA.Value=2; 
			}
			genotypeVE.push_back(TypeA);
		//	cerr<<TypeA.Value<<" ";
		}
//		cerr<<endl;


		GeneID=inf[0];
		istringstream isone (inf[1],istringstream::in);
		isone>> Site ;


		map <string,map <llong, vector <BaseType> > >  :: iterator itSNP=SNPList.find(GeneID);

		if (itSNP == SNPList.end())
		{
			map <llong, vector <BaseType> > DD;
			DD[Site]=genotypeVE;
			SNPList.insert(map <string,map <llong,vector <BaseType> > > ::value_type(GeneID,DD));
			Flag_for_pro++;
		}
		else
		{
			(itSNP->second).insert(map <llong, vector <BaseType> >  :: value_type(Site,genotypeVE)) ;
			Flag_for_pro++;
		}
	}


	if (BadSite!=0)
	{
		cerr<<"Warning skip non bi-allelic(Singleton/ThreeMulti allelic) site, and total skip allelic sites number is :"<<BadSite<<endl;
	}


}







inline int OUTStatFile( In3str1v * paraFA04, Para_18 * para_18 , StarRsult *All_Stat )
{
	string Stat=(paraFA04->InStr2)+".stat.gz";
	ogzstream OUT ((Stat).c_str());	
	if((!OUT.good()))
	{
		cerr << "open OUT File error: "<<(paraFA04->InStr2)<<endl;
		return  0;
	}

	map <llong , StarRsult > :: iterator key_stat ;
	OUT<<"#Dist\tMean_r^2\tMean_D'\tSum_r^2\tSum_D'\tNumberPairs\n";

	(paraFA04->InInt)++;

	if (( (paraFA04->TF) <2 ) ||  ((paraFA04->TF) > 5 ) )
	{
		for (int ii=1 ; ii<(paraFA04->InInt) ; ii++ )
		{
			int count=(All_Stat[ii]).Count;
			if  (count==0)	{continue ;	}
			double SumRR=(All_Stat[ii]).sumRR;
			double MeanRR=SumRR/count;
			OUT<<ii<<setprecision(4)<<setiosflags(ios::right)<<setiosflags(ios::fixed)<<"\t"<<MeanRR<<"\tNA\t"<<SumRR<<"\tNA\t"<<count<<"\n";
		}
	}
	else
	{
		for (int ii=1 ; ii<(paraFA04->InInt) ; ii++ )
		{
			int count=(All_Stat[ii]).Count;
			if  (count==0)	{continue ;	}
			double SumRR=(All_Stat[ii]).sumRR;
			double SumD=(All_Stat[ii]).sumD;

			double MeanRR=SumRR/count;
			double MeanD=SumD/count;
			OUT<<ii<<setprecision(4)<<setiosflags(ios::right)<<setiosflags(ios::fixed)<<"\t"<<MeanRR<<"\t"<<MeanD<<"\t"<<SumRR<<"\t"<<SumD<<"\t"<<count<<"\n";
		}
	}


	OUT.close();

	return 1  ;
}




#endif // LDDecay_H_ //
///////// swimming in the sky and flying in the sea ////////////

