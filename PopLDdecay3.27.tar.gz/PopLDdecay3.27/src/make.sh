#!/bin/sh
#$ -S /bin/sh
echo Start Time : 
date
g++	LD_Decay.cpp	-lgzstream	-L./include/gzstream/	-lz	-L./include/zlib/	-o	../bin/PopLDdecay	
echo done see the [ ../bin/PopLDdecay ]
echo End Time : 
date
