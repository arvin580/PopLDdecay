#ifndef LDDecay_H_
#define LDDecay_H_

#include "HeadIN.h"
#include "FileDeal.h"
#include "Calculate.h"
#include "ProMethod1.h"
#include "ProMethod2.h"

using namespace std;

int  LDdecaySNP_help()
{
	cout <<""
		"\n"
		"\tUsage: PopLDDecay -InVCF  <in.vcf.gz>  -OutStat <out.stat>\n"
		"\n"
		"\t\t-InVCF       <str>    Input SNP VCF Format\n"
		"\t\t-InGenotype  <str>    Input SNP Genotype Format\n"
		"\t\t-OutStat     <str>    OutPut Stat Dist ~ r^2 File\n"
		"\n"
		"\t\t-SubPop      <str>    SubGroup SampleList of VCFFile [ALLsample]\n"
		"\t\t-MaxDist     <int>    Max Distance (kb) between two SNP [300]\n"
		"\t\t-MAF         <float>  Min minor allele frequency filter [0.005]\n"
		"\t\t-Het         <float>  Max ratio of het allele filter [0.88]\n"
		"\t\t-Miss        <float>  Max ratio of miss allele filter [0.25]\n"
		"\t\t-OutFilterSNP         OutPut the final SNP to calculate\n"
		"\t\t-OutPairLD   <int>    OutPut the PairWise SNP LD info [0]\n"
		"\t\t                      0/2:No_Out 1/3/4:Out_Brief 5:Out_Full\n"
		"\t\t-Methold     <int>    Select the Cal agorithm [1]\n"
		"\t\t                      1:Low MEM  2 May Big MEM\n"
		"\t\t\n"
		"\t\t-help                 Show this help [hewm2008 v3.27]\n"
		"\n";
	return 1;
}

int LDdecay_help01(int argc, char **argv , In3str1v * paraFA04, Para_18 * para_18)
{
	if (argc <=2 ) {LDdecaySNP_help();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InVCF")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr1=argv[i];
		}
		else if (flag  == "InGenotype")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr3=argv[i];
		}
		else if (flag  == "InSNP")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr3=argv[i];
		}
		else if (flag  == "SubPop")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->SubPop=argv[i];
		}
		else if (flag  ==  "OutStat")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr2=argv[i];
		}
		else if (flag  == "Het" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_18->Het=atof(argv[i]);
		}
		else if (flag == "MAF")
		{
			if(i + 1== argc) {LogLackArg(flag);return 0;}
			i++;
			para_18->MAF=atof(argv[i]);
		}
		else if (flag == "Miss")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_18->Miss=atof(argv[i]);
		}
		else if (flag == "MaxDist" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			paraFA04->InInt=atoi(argv[i]);
		}
		else if (flag == "OutPairLD")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			paraFA04->TF=atoi(argv[i]);
		}
		else if (flag == "Methold")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			paraFA04->Method=atoi(argv[i]);
		}
		else if (flag == "OutFilterSNP")
		{
			paraFA04->TF2=false;
		}
		else if (flag == "help")
		{
			LDdecaySNP_help();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ( (paraFA04->InStr2).empty() ||( (paraFA04->InStr1).empty() &&  (paraFA04->InStr3).empty() )  )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	return 1 ;
}


int main(int argc, char *argv[])
{
	In3str1v *paraFA04 = new In3str1v;
	Para_18 * para_18 = new Para_18 ;
	//paraFA04->InInt=300;	para_18->MAF=0.005;	para_18->Miss=0.25;
	
	if ( (LDdecay_help01(argc, argv, paraFA04, para_18)==0) )
	{
		delete paraFA04 ;
		delete para_18 ;
		return 0 ;
	}
	(paraFA04->InInt)=(paraFA04->InInt)*1000;



	char buf[1024*1024]; 	setbuf(stdout, buf);


	string Stat=(paraFA04->InStr2)+".stat.gz";
	ogzstream OUTTest ((Stat).c_str());	
	if((!OUTTest.good()))
	{
		cerr << "open OUT File error: "<<(paraFA04->InStr2)<<endl;
		delete para_18 ;
		delete  paraFA04 ; return  0;
	}
	OUTTest.close();


	map <string,map <llong, vector <BaseType> > >  SNPList ;
	int Flag_for_pro=0;

	/////*               VCF   IN Deal //////////////////////*////
	if (!(paraFA04->InStr1).empty())
	{
		if ((paraFA04->SubPop).empty())
		{
			Read_VCF_IN( paraFA04, para_18 , SNPList, Flag_for_pro);
		}
		else
		{
			Read_SubPopVCF_IN( paraFA04, para_18 , SNPList, Flag_for_pro);
		}
	}

	/////*               Genotype IN Deal //////////////////////*////
	if (!(paraFA04->InStr3).empty())
	{
		if  ((paraFA04->SubPop).empty())
		{
		Read_Genotype_IN(paraFA04, para_18 ,SNPList,Flag_for_pro);
		}
		else
		{
			Read_SubPopGenotype_IN(paraFA04, para_18 ,  SNPList , Flag_for_pro );
		}
	}


	//*///////////////////////////PairWise Compare//////////////////////////////////*//

	StarRsult *All_Stat = new StarRsult [((paraFA04->InInt)+1)];
	
	if ((paraFA04->Method)==2)
	{
	PairWiseComV2(paraFA04, para_18 , SNPList ,  All_Stat , Flag_for_pro );
	}
	else
	{
	PairWiseComV1(paraFA04, para_18 , SNPList ,  All_Stat , Flag_for_pro );
	}



	////* OUT Stat  File /*/////
	OUTStatFile( paraFA04, para_18 , All_Stat );
	cerr<<"Used [perl  ../bin/Plot_XX.pl ] to Plot the LDdecay"<<endl;

	delete All_Stat ;
	delete para_18 ;
	delete paraFA04 ;
	return 0;

}




#endif // LDDecay_H_ //
///////// swimming in the sky and flying in the sea ////////////

